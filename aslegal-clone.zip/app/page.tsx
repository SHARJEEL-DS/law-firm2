"use client"

import Image from "next/image"
import { ChevronDown } from "lucide-react"
import { useState, useEffect } from "react"

export default function HomePage() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const slides = [
    { image: "/slider1.png", alt: "Legal office interior" },
    { image: "/slider2.png", alt: "Fountain pen on documents" },
    { image: "/slider3.png", alt: "Law office meeting room" },
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [slides.length])

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-gray-700 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-gray-700 via-gray-600 to-gray-500"></div>
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-white/30 to-transparent transform skew-x-12 translate-x-16"></div>

        <div className="relative z-10 container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 border-2 border-white"></div>
              <div className="text-sm font-light tracking-wider">
                <div className="font-bold text-lg">AS LEGAL</div>
                <div className="text-xs opacity-90">ADVOKÁTSKA</div>
                <div className="text-xs opacity-90">KANCELÁRIA</div>
                <div className="text-xs opacity-90">BRATISLAVA</div>
              </div>
            </div>

            {/* Centered Navigation */}
            <nav className="hidden md:flex items-center space-x-12 absolute left-1/2 transform -translate-x-1/2">
              <div className="flex items-center space-x-1 cursor-pointer hover:text-cyan-300 transition-colors">
                <span className="text-sm font-light tracking-wide">SLUŽBY</span>
                <ChevronDown className="w-4 h-4" />
              </div>
              <div className="flex items-center space-x-1 cursor-pointer hover:text-cyan-300 transition-colors">
                <span className="text-sm font-light tracking-wide">O NÁS</span>
                <ChevronDown className="w-4 h-4" />
              </div>
              <div className="cursor-pointer hover:text-cyan-300 transition-colors">
                <span className="text-sm font-light tracking-wide">KONTAKT</span>
              </div>
            </nav>

            {/* Mobile menu button */}
            <button className="md:hidden text-white">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </header>

      {/* Hero Slider Section */}
      <section className="relative h-[500px] md:h-[600px] overflow-hidden">
        {/* Slider Images */}
        <div className="absolute inset-0">
          {slides.map((slide, index) => (
            <div
              key={index}
              className={`absolute inset-0 transition-opacity duration-1000 ${
                index === currentSlide ? "opacity-100" : "opacity-0"
              }`}
            >
              <Image
                src={slide.image || "/placeholder.svg"}
                alt={slide.alt}
                fill
                className="object-cover"
                priority={index === 0}
              />
              <div className="absolute inset-0 bg-black/20"></div>
            </div>
          ))}
        </div>

        {/* Content Overlay */}
        <div className="relative z-10 container mx-auto px-4 h-full flex items-center">
          <div className="bg-cyan-400 text-white p-8 md:p-12 max-w-md shadow-lg">
            <h1 className="text-3xl md:text-4xl font-light mb-4">Starostlivosť</h1>
            <p className="text-lg md:text-xl font-light leading-relaxed">
              Vaše záujmy v<br />
              centre pozornosti
            </p>
          </div>
        </div>

        {/* Navigation dots */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-3">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 rounded-full transition-colors duration-300 ${
                index === currentSlide ? "bg-cyan-400" : "bg-white/50 hover:bg-white/70"
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 md:gap-12">
            {/* Dobré zmluvy */}
            <div className="space-y-6">
              <div className="border-b-2 border-gray-300 pb-2">
                <h2 className="text-xl md:text-2xl font-light text-gray-800">Dobré zmluvy</h2>
              </div>
              <div className="space-y-4 text-gray-600 text-sm leading-relaxed">
                <p>
                  Zmluvy pre Vás navrhujeme, upravujeme i kontrolujeme. Upozorňujeme na dôležité body zmluvných vzťahov
                  a vyhodnocujeme ich relevantné súvislosti. Radíme Vám pri rokovaniach s obchodnými partnermi a v
                  prípade potreby vyjednávame vo Vašom mene.
                </p>
                <p>
                  Vo svete záväzkov spravidla platí, že dobré zmluvy robia dobrých priateľov.{" "}
                  <span className="text-cyan-500 cursor-pointer hover:underline">Viac...</span>
                </p>
              </div>
            </div>

            {/* Férový proces */}
            <div className="space-y-6">
              <div className="border-b-2 border-gray-300 pb-2">
                <h2 className="text-xl md:text-2xl font-light text-gray-800">Férový proces</h2>
              </div>
              <div className="space-y-4 text-gray-600 text-sm leading-relaxed">
                <p>
                  Dohliadame na to, aby Vaše konanie pred súdom alebo správnym orgánom prebiehalo v súlade so zákonom a
                  právom na spravodlivý proces. Pripravujeme kvalifikované podania, vyhotovujeme stratégiu pre vedenie
                  sporu a zastupujeme Vaše záujmy na pojednávaniach.
                </p>
                <p>
                  Súčasný stav právneho prostredia klade na účastníkov konania vysoké nároky.{" "}
                  <span className="text-cyan-500 cursor-pointer hover:underline">Viac...</span>
                </p>
              </div>
            </div>

            {/* Odborná ochrana */}
            <div className="space-y-6">
              <div className="border-b-2 border-gray-300 pb-2">
                <h2 className="text-xl md:text-2xl font-light text-gray-800">Odborná ochrana</h2>
              </div>
              <div className="space-y-4 text-gray-600 text-sm leading-relaxed">
                <p>
                  Poskytujeme právne poradenstvo, ktoré Vám pomáha vyriešiť svoje práva, poznať povinnosti a vyjasniť si
                  sporné otázky. Predkladáme Vám zrozumiteľné právne analýzy, vykonávame právne audity (due diligence) a
                  organizujeme školenia na mieru podľa Vašej potreby.
                </p>
                <p>
                  Cieľom našej odbornej ochrany je pôsobiť predovšetkým preventívne.{" "}
                  <span className="text-cyan-500 cursor-pointer hover:underline">Viac...</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 md:gap-12">
            {/* Kto sme */}
            <div className="space-y-6">
              <div className="border-b-2 border-gray-300 pb-2">
                <h2 className="text-xl md:text-2xl font-light text-gray-800">Kto sme</h2>
              </div>
              <div className="space-y-4 text-gray-600 text-sm leading-relaxed">
                <p>
                  AS LEGAL patri medzi malé až stredne veľké advokátske kancelárie s dôrazom na vysokú prevenciu a
                  zastupovanie v súdnych sporoch. Stabilný tím šiestich členov AS LEGAL sa stará o to, aby ste vždy
                  dostali potrebné odpovede a efektívnu obhajobu Vašich práv a záujmov.
                </p>
                <p>
                  Vo svete záväzkov spravidla platí, že dobré zmluvy robia dobrých priateľov.{" "}
                  <span className="text-cyan-500 cursor-pointer hover:underline">Viac...</span>
                </p>
              </div>
            </div>

            {/* Ako pracujeme */}
            <div className="space-y-6">
              <div className="border-b-2 border-gray-300 pb-2">
                <h2 className="text-xl md:text-2xl font-light text-gray-800">Ako pracujeme</h2>
              </div>
              <div className="space-y-4 text-gray-600 text-sm leading-relaxed">
                <p>
                  Spolupráca s AS LEGAL prebieha v priateľskej atmosfére. Vaše problémy vnímame ako prednostné problémy
                  a pomenuujeme ich čo možno riešenia. Nasledky stále krátka právna rada, po mnohé prípady (najmä súdne
                  spory) môžu vyžadovať úkony aj v dlhšom období.
                </p>
                <p>
                  Preto chceme, aby ste našu službu mali po celú dobu pod kontrolou, zaplatili len za to, čo skutočne
                  vykonáme a platbu si prispôsobili čo najviac podľa vlastných predstáv.{" "}
                  <span className="text-cyan-500 cursor-pointer hover:underline">Viac...</span>
                </p>
              </div>
            </div>

            {/* Kde nás nájdete */}
            <div className="space-y-6">
              <div className="border-b-2 border-gray-300 pb-2">
                <h2 className="text-xl md:text-2xl font-light text-gray-800">Kde nás nájdete</h2>
              </div>
              <div className="space-y-4 text-gray-600 text-sm leading-relaxed">
                <p>
                  AS LEGAL advokátska kancelária, Bratislava sa pre Vás nachádza na adrese od 9:00 do 17:00 v pracovné
                  dni. Sídlime na ulici Hlboká 1/11, Bratislava (pri Trnavskom mýte) a odpovieme aj na tel. č.:
                  02/44454498 alebo e-mailom: kancelaria@aslegal.sk.
                </p>
                <p>
                  Ak máte záujem o službu, ktoré poskytujeme našim klientom, stačí si vybrať kontakt a my Vám zároveň
                  bezplatne prvé stretnutie v čase, ktorý si sami zvolíte.{" "}
                  <span className="text-cyan-500 cursor-pointer hover:underline">Viac...</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Standardized Services Section */}
      <section className="py-12 md:py-16 bg-gray-50 border-t border-gray-200">
        <div className="container mx-auto px-4">
          {/* Top border line */}
          <div className="w-full h-px bg-gray-300 mb-8"></div>

          <div className="text-center space-y-6">
            <h2 className="text-lg font-normal text-cyan-500 tracking-wide">
              PREDSTAVUJEME ŠTANDARDIZOVANÉ PRÁVNE SLUŽBY:
            </h2>

            <div className="max-w-4xl mx-auto space-y-4 text-sm text-gray-600 leading-relaxed">
              <p>
                V roku 2016 sme pre Vás vytvorili pilotný projekt, zameraný na uľahčenie prístupu k právnym službám,
                dostupný na našej webstránke:{" "}
                <a href="https://zalozeniesropredaj.sk/" className="text-cyan-500 hover:underline">
                  https://zalozeniesropredaj.sk/
                </a>
              </p>

              <p>
                Projekt ponúka jednoduché a rýchle{" "}
                <span className="text-cyan-500">založenie s.r.o. alebo predaj s.r.o.</span>, ako aj ďalšie užitočné
                služby pre podnikateľov a obchodné spoločnosti. Vďaka štandardizácii šetríme náklady a služba sa stáva
                dostupnejšou, pričom dohľad advokátov nad celým postupom ostáva zachovaný.
              </p>
            </div>
          </div>

          {/* Bottom border line */}
          <div className="w-full h-px bg-gray-300 mt-8 mb-8"></div>

          {/* 4-Step Process */}
          <div className="text-center space-y-8">
            <p className="text-gray-600 text-sm">
              Spoznajte AS LEGAL v štyroch jednoduchých krokoch, ktoré Vám nezaberú viac ako niekoľko minút.
            </p>

            <div className="grid md:grid-cols-4 gap-6 max-w-5xl mx-auto">
              <div className="text-center space-y-2">
                <div className="text-4xl font-light text-gray-800 mb-2">1</div>
                <div className="text-sm text-gray-600">
                  Zistite viac <span className="text-cyan-500 font-medium">O SLUŽBE</span>,<br />
                  ktorú ponúkame
                </div>
              </div>

              <div className="text-center space-y-2">
                <div className="text-4xl font-light text-gray-800 mb-2">2</div>
                <div className="text-sm text-gray-600">
                  Prečítajte si <span className="text-cyan-500 font-medium">O NÁS</span>,<br />
                  čo Vás zaujíma
                </div>
              </div>

              <div className="text-center space-y-2">
                <div className="text-4xl font-light text-gray-800 mb-2">3</div>
                <div className="text-sm text-gray-600">
                  Informujte sa <span className="text-cyan-500 font-medium">O CENE</span>,<br />
                  za právne služby
                </div>
              </div>

              <div className="text-center space-y-2">
                <div className="text-4xl font-light text-gray-800 mb-2">4</div>
                <div className="text-sm text-gray-600">
                  Vyberte si <span className="text-cyan-500 font-medium">KONTAKT</span>,<br />
                  ktorý Vám vyhovuje
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-700 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            {/* Štandardizované služby */}
            <div className="space-y-4">
              <h3 className="text-lg font-normal mb-4">Štandardizované služby</h3>
              <div className="space-y-2 text-sm text-gray-300">
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Založenie s.r.o., zmeny a zrušenie s.r.o.
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Prevod nehnuteľností a vklad na kataster
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Zrušenie a vysporiadanie BSM
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Pracovnoprávne zmluvy a dohody
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Žiadosť o podmienečné prepustenie
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Registrácia ochrannej známky / dizajnu
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Ústavná sťažnosť na prieťahy v konaní
                  </a>
                </div>
              </div>
            </div>

            {/* Odborné zameranie */}
            <div className="space-y-4">
              <h3 className="text-lg font-normal mb-4">Odborné zameranie</h3>
              <div className="space-y-2 text-sm text-gray-300">
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Obchodné právo
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Občianske právo
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Rodinné právo
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Pracovné právo
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Trestné právo
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Právo duševného vlastníctva
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Ľudské práva a slobody
                  </a>
                </div>
              </div>
            </div>

            {/* Užitočné právne linky */}
            <div className="space-y-4">
              <h3 className="text-lg font-normal mb-4">Užitočné právne linky</h3>
              <div className="space-y-2 text-sm text-gray-300">
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Slov-Lex - elektronická zbierka zákonov
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    EUR-Lex - prístup k právu Európskej únie
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Slovenská advokátska komora
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Ministerstvo spravodlivosti SR
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Ústavný súd Slovenskej republiky
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Najvyšší súd Slovenskej republiky
                  </a>
                </div>
                <div>
                  <a href="#" className="hover:text-cyan-300 transition-colors">
                    Úrad priemyselného vlastníctva SR
                  </a>
                </div>
              </div>
            </div>

            {/* Ďalšie informácie */}
            <div className="space-y-4">
              <h3 className="text-lg font-normal mb-4">Ďalšie informácie</h3>
              <div className="space-y-4 text-sm text-gray-300">
                <div>
                  <p>© 2008 - 2017 AS Legal s.r.o.</p>
                  <p>Advokátska kancelária Bratislava</p>
                  <p>
                    <a href="#" className="hover:text-cyan-300 transition-colors">
                      Viac informácií o cookies
                    </a>
                  </p>
                </div>

                <div className="pt-4 border-t border-gray-600">
                  <p>
                    E-mail:{" "}
                    <a href="mailto:kancelaria@aslegal.sk" className="text-cyan-300 hover:underline">
                      kancelaria@aslegal.sk
                    </a>
                  </p>
                  <p>Tel: 02 / 444 544 98</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
